# CCCP + Marketing — mock data removed, cross-dashboard flows checked

Copy these files over the same paths in `thoughtflows-hrms-crm/` and restart the server.

## Server
- server/src/models/CollegePartner.js — `code`, `studentStrength` now saved; no default city; MOU = Not Signed | Draft | Signed
- server/src/models/CorporatePartner.js — `code` saved; no default city; activeVacancies default 0 (was 10)
- server/src/routes/api.js
  - colleges/companies: server assigns codes (CLG-CBE-001 / CMP-HYD-001), name required, legacy MOU values normalised
  - follow-ups: PUT + DELETE added (mark done), sorted by date + time
  - placements: CCCP status now mirrors onto the student (placementStatus; Joined → statusGroup "placed") so HR's Placed tab, Leadership and Student portal match

## Client
- services/api.js — updateCccpFollowUp / deleteCccpFollowUp
- CccpDashboard.jsx — see summary in chat
- MarketingDepartmentDashboard.jsx + BranchLeadDemandBoard / ContentCalendarBoard / CreativeApprovalDesk / RoiReportsBoard — all on live API
- HrAdmittedStudentsCrm.jsx — exam-status dropdown keeps CCCP-written values visible
